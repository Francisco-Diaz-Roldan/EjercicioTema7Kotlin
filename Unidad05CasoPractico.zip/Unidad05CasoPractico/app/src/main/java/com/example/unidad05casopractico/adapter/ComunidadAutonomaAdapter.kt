package com.example.unidad05casopractico.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.unidad05casopractico.model.ComunidadAutonoma
import com.example.unidad05casopractico.viewholder.ComunidadAutonomaViewHolder
import com.example.unidad05casopractico.R

class ComunidadAutonomaAdapter (
    private var comunidadAutonomaLista:List<ComunidadAutonoma>,
    private val  onClickListener:(ComunidadAutonoma)->Unit): RecyclerView.Adapter<ComunidadAutonomaViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ComunidadAutonomaViewHolder {
        val layoutInflater= LayoutInflater.from(parent.context)
        return ComunidadAutonomaViewHolder(layoutInflater.inflate(R.layout.item_comunidad_autonoma, parent, false))
    }

    override fun onBindViewHolder(holder: ComunidadAutonomaViewHolder, position:Int){
        val item=comunidadAutonomaLista[position]
        holder.render(item, onClickListener)
    }

    fun actualizarLista(nuevaLista: List<ComunidadAutonoma>) {
        comunidadAutonomaLista = nuevaLista
        notifyDataSetChanged()
    }

    override fun getItemCount(): Int {
        return comunidadAutonomaLista.size
    }
}