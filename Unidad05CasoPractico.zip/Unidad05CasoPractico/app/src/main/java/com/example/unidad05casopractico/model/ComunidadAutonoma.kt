package com.example.unidad05casopractico.model

data class ComunidadAutonoma (
    var id:Int,
    var nombre:String,
    val imagen:Int,
    var esVisible: Int = 0
)
