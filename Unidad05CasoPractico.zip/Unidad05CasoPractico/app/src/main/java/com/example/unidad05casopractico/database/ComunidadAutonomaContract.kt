package com.example.unidad05casopractico.database

import android.provider.BaseColumns

class ComunidadAutonomaContract {
    companion object{
        const val NOMBRE_BD = "comunidades_autonomas"
        const val VERSION = 1
        class Entrada: BaseColumns {
            companion object{
                const val NOMBRE_TABLA = "comunidades_autonomas"
                const val COLUMNA_ID = "id"
                const val COLUMNA_NOMBRE = "nombre"
                const val COLUMNA_IMAGEN = "imagen"
            }
        }
    }
}
