package com.example.unidad05casopractico.viewholder

import android.view.ContextMenu
import android.view.View
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.unidad05casopractico.databinding.ItemComunidadAutonomaBinding
import com.example.unidad05casopractico.model.ComunidadAutonoma


class ComunidadAutonomaViewHolder (view: View): RecyclerView.ViewHolder(view), View.OnCreateContextMenuListener {

    private val binding = ItemComunidadAutonomaBinding.bind(view)
    private lateinit var comunidadAutonoma: ComunidadAutonoma


    fun render(item: ComunidadAutonoma, onClickListener: (ComunidadAutonoma)->Unit){
        comunidadAutonoma=item
        binding.tvComunidadAutonomaNombre.text=item.nombre
        binding.ivComunidadAutonoma.setImageResource(item.imagen)
        Glide.with(binding.ivComunidadAutonoma.context).load(item.imagen).into(binding.ivComunidadAutonoma)

        itemView.setOnClickListener{
            onClickListener(item)
        }
        itemView.setOnCreateContextMenuListener(this)
    }


    override fun onCreateContextMenu(
        menu: ContextMenu?,
        v:View?,
        menuInfo: ContextMenu.ContextMenuInfo?
    ){
        menu!!.setHeaderTitle(comunidadAutonoma.nombre)
        menu.add(this.adapterPosition,0,0,"Eliminar")
        menu.add(this.adapterPosition,1,1,"Editar")
    }


}