package com.example.unidad05casopractico.activities

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView.LayoutManager
import com.example.unidad05casopractico.model.ComunidadAutonoma
import com.example.unidad05casopractico.R
import com.example.unidad05casopractico.adapter.ComunidadAutonomaAdapter
import com.example.unidad05casopractico.database.ComunidadAutonomaDAO
import com.example.unidad05casopractico.databinding.ActivityMainBinding
import com.example.unidad05casopractico.provider.ComunidadAutonomaProvider
import com.google.android.material.snackbar.Snackbar


class MainActivity : AppCompatActivity() {

    private lateinit var binding:ActivityMainBinding
    private lateinit var adapter: ComunidadAutonomaAdapter
    private lateinit var layoutManager:LayoutManager
    private lateinit var listaComunidadesAutonomas:MutableList<ComunidadAutonoma>
    lateinit var miDAO: ComunidadAutonomaDAO

    //Creo el intentLaunch y establezco valores predeterminados para nombre, id y la imagen
    private lateinit var intentLaunch: ActivityResultLauncher<Intent>
    private var nombre="Sin nombre"
    private var id:Int=0
    private var imagenComunidadAutonoma: Int = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Inicializo la base de datos con la lista de ComunidadAutonoma
        miDAO = ComunidadAutonomaDAO()
        listaComunidadesAutonomas = miDAO.cargarLista(this)

        // Configuro el RecyclerView y el adaptador
        layoutManager = LinearLayoutManager(this)
        binding.rvComunidadesAutonomas.layoutManager = layoutManager
        adapter = ComunidadAutonomaAdapter(listaComunidadesAutonomas) { comunidadAutonoma ->
            onItemSelected(comunidadAutonoma)
        }
        binding.rvComunidadesAutonomas.adapter = adapter
        binding.rvComunidadesAutonomas.setHasFixedSize(true)
        binding.rvComunidadesAutonomas.itemAnimator = DefaultItemAnimator()

        // Inicializo el intentLaunch después de configurar la base de datos y el RecyclerView
        intentLaunch = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                val data = result.data
                val nombreActualizado = data?.getStringExtra("nombreComunidadAutonoma")
                val idComunidadAutonoma = data?.getIntExtra("idComunidadAutonoma", -1)

                if (nombreActualizado != null && idComunidadAutonoma != -1) {
                    // Actualiza la lista en memoria
                    listaComunidadesAutonomas[idComunidadAutonoma!!].nombre = nombreActualizado

                    // Actualiza la base de datos con el nuevo nombre
                    miDAO.actualizarBBDD(this, listaComunidadesAutonomas[idComunidadAutonoma!!])

                    // Notifica al adapter que los datos han cambiado
                    if (idComunidadAutonoma != null) {
                        adapter.notifyItemChanged(idComunidadAutonoma)
                    }
                }
            }
        }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_desplegable,menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when(item.itemId){
            R.id.addComunidadAutonoma -> {
                addComunidadAutonoma()
                true
            }

            R.id.limpiar -> {
                limpiar()
                true
            }

            R.id.recargar -> {
                recargar()
                true
            }

            else -> super.onOptionsItemSelected(item)
        }
    }
    /*private fun limpiar() {
        // Filtrar la lista para mostrar solo elementos con esVisible igual a 0
        val listaFiltrada = listaComunidadesAutonomas.filter { it.esVisible == 0 }

        // Actualiza el adaptador con la lista filtrada
        adapter.actualizarLista(listaFiltrada)

        // Notifica al adaptador que los datos han cambiado
        adapter.notifyDataSetChanged()

        Toast.makeText(this, "Lista limpiada", Toast.LENGTH_SHORT).show()
    }*/
    private fun limpiar() {
        // Cambio esVisible a 0 para todas las comunidades autonomas (no las muestro por pantalla)
        listaComunidadesAutonomas.forEach { it.esVisible = 0 }

        // Actualizo la base de datos
        for (comunidadAutonoma in listaComunidadesAutonomas) {
            miDAO.actualizarBBDD(this, comunidadAutonoma)
        }

        // Filtro la lista para mostrar las comunidades autonomas
        val listaFiltrada = listaComunidadesAutonomas.filter { it.esVisible == 1 }

        // Actualizo el adaptador con la lista filtrada
        adapter.actualizarLista(listaFiltrada)

        // Indico los cambios al adaptador
        adapter.notifyDataSetChanged()

        Toast.makeText(this, "Lista limpiada", Toast.LENGTH_SHORT).show()
    }

    @SuppressLint("NotifyDataSetChanged")
    private fun recargar() {
        listaComunidadesAutonomas.forEach { it.esVisible = 1 }

        for (comunidadAutonoma in listaComunidadesAutonomas) {
            miDAO.actualizarBBDD(this, comunidadAutonoma)
        }

        // Filtro la lista para mostrarlas comunidades autonomas visibles
        val listaFiltrada = listaComunidadesAutonomas.filter { it.esVisible == 1 }

        // Actualizo el adaptador con la lista filtrada
        adapter.actualizarLista(listaFiltrada)

        // Indico los cambios al adaptador
        adapter.notifyDataSetChanged()

        Toast.makeText(this, "Lista recargada", Toast.LENGTH_SHORT).show()
    }

    private fun addComunidadAutonoma() {
        // Creo una nueva comunidad autónoma que es visible de forma prederterminada
        val nuevaComunidad = ComunidadAutonoma(
            listaComunidadesAutonomas.size + 1,
            "Comunidad ${listaComunidadesAutonomas.size + 1}",
            R.drawable.andorra, 1
        )

        // Añado la nueva comunidad autónoma a ComunidadAutonomaProvider
        ComunidadAutonomaProvider.listaComunidadesAutonomas.add(nuevaComunidad)

        // Añado la nueva comunidad autónoma a la lista
        listaComunidadesAutonomas.add(nuevaComunidad)


        // Actualizo la base de datos
        miDAO.actualizarBBDD(this, nuevaComunidad)

        // Filtro la lista para mostrar las comunidades autonomas visibles
        val listaFiltrada = listaComunidadesAutonomas.filter { it.esVisible == 1 }

        // Actualizo el adaptador con la lista filtrada
        adapter.actualizarLista(listaFiltrada)
        adapter.notifyDataSetChanged()

        // Indico los cambios al adaptador
        val posicionNueva = listaComunidadesAutonomas.indexOf(nuevaComunidad)
        layoutManager.scrollToPosition(posicionNueva)

        Toast.makeText(this, "Comunidad autónoma añadida", Toast.LENGTH_SHORT).show()
    }




    /*private fun limpiar() {
        listaComunidadesAutonomas.forEach { it.esVisible = 0 }

        for (comunidadAutonoma in listaComunidadesAutonomas) {
            miDAO.actualizarBBDD(this, comunidadAutonoma)
        }
        // Borra todos los elementos visibles de la lista
        //listaComunidadesAutonomas.removeAll { it.esVisible == 0 }

        // Notifica al adaptador que los datos han cambiado
        adapter.actualizarLista(listaComunidadesAutonomas)
        adapter.notifyDataSetChanged()

        Toast.makeText(this, "Lista limpiada", Toast.LENGTH_SHORT).show()
    }*/

    /*private fun recargar() {
        for (comunidadAutonoma in listaComunidadesAutonomas) {
            comunidadAutonoma.esVisible = 1
            miDAO.actualizarBBDD(this, comunidadAutonoma)
        }

        // Le indico al adaptador que los datos han cambiado
        adapter.actualizarLista(listaComunidadesAutonomas)
        adapter.notifyDataSetChanged()

        // Actualizo la vista del RecyclerView
        binding.rvComunidadesAutonomas.invalidate()
        Toast.makeText(this, "Lista recargada", Toast.LENGTH_SHORT).show()
    }*/
/*
    private fun addComunidadAutonoma() {
        // Creo una nueva comunidad autónoma con valores predeterminados
        val nuevaComunidad = ComunidadAutonoma(
            listaComunidadesAutonomas.size + 1,
            "Comunidad ${listaComunidadesAutonomas.size + 1}",
            R.drawable.andorra,
            1  // Establezco esVisible a 1
        )
        // Inserto la nueva comunidad autónoma al principio de la lista
        listaComunidadesAutonomas.add(0, nuevaComunidad)

        // Actualizo la base de datos
        miDAO.actualizarBBDD(this, nuevaComunidad)

        // Le indico al adaptador que se insertó un nuevo elemento al principio de la lista
        adapter.notifyItemInserted(0)
        layoutManager.scrollToPosition(0)
        Toast.makeText(this, "Comunidad autónoma añadida", Toast.LENGTH_SHORT).show()
    }
*/


    override fun onContextItemSelected(item: MenuItem): Boolean {
        val comunidadAutonomaAfectada = listaComunidadesAutonomas[item.groupId]
        when (item.itemId) {
            0 -> { // Opción para eliminar una comunidad autónoma,hace referencia a la primera opción del menú contextual

                // Elimino el elemento de la lista
                val position = item.groupId
                listaComunidadesAutonomas.removeAt(position)

                // Notifico el adaptador que los datos han cambiado
                adapter.notifyItemRemoved(position)

                // Actualizo la base de datos eliminando la comunidad autónoma
                miDAO.borrarBBDD(this, comunidadAutonomaAfectada.id)

                display("Se ha eliminado ${comunidadAutonomaAfectada.nombre}")
            }
            1 -> { // Opción para editar una comunidad autónoma, hace referencia a la segunda opción del menú contextual que lleva a la otra pantalla

                val miIntent = Intent(this, EditComunidadAutonomaActivity::class.java)
                miIntent.putExtra("nombreComunidadAutonoma", comunidadAutonomaAfectada.nombre)
                miIntent.putExtra("idComunidadAutonoma", item.groupId)
                miIntent.putExtra("imagenComunidadAutonoma", comunidadAutonomaAfectada.imagen)
                intentLaunch.launch(miIntent)
            }
        }
        return true
    }


    private fun display(message: String) {
        Snackbar.make(binding.root,message, Snackbar.LENGTH_SHORT).show()
    }


    private fun onItemSelected(comunidadAutonoma: ComunidadAutonoma) {
        Toast.makeText(this,"Yo soy de ${comunidadAutonoma.nombre}", Toast.LENGTH_SHORT).show()
    }
}
    /* private fun recargar() {
             // Verifico si la lista está vacía
             if (listaComunidadesAutonomas.isNotEmpty()) {
                 Toast.makeText(this, "La lista ya está recargada", Toast.LENGTH_SHORT).show()
             } else {
                 // Recorro la lista y configuro la propiedad 'esVisible' a 1
                 for (comunidadAutonoma in listaComunidadesAutonomas) {
                     comunidadAutonoma.esVisible = 1
                 }

                 // Creo una nueva lista a partir de la lista actual
                 val nuevaLista = listaComunidadesAutonomas.toList()

                 // Limpio la lista actual
                 listaComunidadesAutonomas.clear()

                 // Agrego los elementos de la nueva lista a la lista original
                 listaComunidadesAutonomas.addAll(nuevaLista)

                 // Actualizo el adaptador con la nueva lista
                 adapter.actualizarLista(listaComunidadesAutonomas)

                 // Muestro un mensaje y desplazo la vista al final de la lista
                 layoutManager.scrollToPosition(listaComunidadesAutonomas.size)
                 Toast.makeText(this, "Lista recargada", Toast.LENGTH_SHORT).show()
             }
         }*/

    /*private fun recargar() {
        //Compruebo que la lista no esté vacía con .isNotEmpty()
        if (listaComunidadesAutonomas.isNotEmpty()) {
           Toast.makeText(this,"La lista ya está recargada",Toast.LENGTH_SHORT).show()
        }else{
            for (comunidadAutonoma in listaComunidadesAutonomas) {
                comunidadAutonoma.esVisible = 1
            }
            crearListaNueva()
            adapter= ComunidadAutonomaAdapter(listaComunidadesAutonomas){ comunidadAutonoma ->
                onItemSelected(comunidadAutonoma)}
            binding.rvComunidadesAutonomas.adapter=adapter
            adapter.notifyItemInserted(listaComunidadesAutonomas.size)
            layoutManager.scrollToPosition(listaComunidadesAutonomas.size)
            Toast.makeText(this, "Lista recargada", Toast.LENGTH_SHORT).show()
        }
    }*/
    /*private fun addComunidadAutonoma() {
        listaComunidadesAutonomas.add(listaComunidadesAutonomas.size,
            ComunidadAutonoma(listaComunidadesAutonomas.size+1,"Comunidad ${listaComunidadesAutonomas.size+1}",
             R.drawable.andorra
            )
        )
        adapter.notifyItemInserted(listaComunidadesAutonomas.size)
        layoutManager.scrollToPosition(listaComunidadesAutonomas.size)
        Toast.makeText(this,"Comunidad autónoma añadida", Toast.LENGTH_SHORT).show()
    }*/


    /* private fun crearListaNueva(){
         val nuevaLista= listaComunidadesAutonomas.toList()
         listaComunidadesAutonomas.clear()
         listaComunidadesAutonomas.addAll(nuevaLista)
     }*/



