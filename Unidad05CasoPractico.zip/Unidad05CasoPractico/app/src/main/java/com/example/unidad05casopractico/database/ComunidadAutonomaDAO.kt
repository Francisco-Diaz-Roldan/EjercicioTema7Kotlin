package com.example.unidad05casopractico.database

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import com.example.unidad05casopractico.activities.MainActivity
import com.example.unidad05casopractico.model.ComunidadAutonoma
import com.example.unidad05casopractico.provider.ComunidadAutonomaProvider.Companion.listaComunidadesAutonomas

class ComunidadAutonomaDAO {
    fun cargarLista(context: Context?): MutableList<ComunidadAutonoma> {
        lateinit var res: MutableList<ComunidadAutonoma>
        lateinit var c: Cursor
        try {
            val db = DBOpenHelper.getInstance(context)!!.readableDatabase
            val columnas = arrayOf(
                ComunidadAutonomaContract.Companion.Entrada.COLUMNA_ID,
                ComunidadAutonomaContract.Companion.Entrada.COLUMNA_NOMBRE,
                ComunidadAutonomaContract.Companion.Entrada.COLUMNA_IMAGEN
            )
            c = db.query(
                ComunidadAutonomaContract.Companion.Entrada.NOMBRE_TABLA,
                columnas, null, null, null, null, null
            )
            res = mutableListOf()
            while (c.moveToNext()) {
                val nueva = ComunidadAutonoma(c.getInt(0), c.getString(1), c.getInt(2), 1)
                res.add(nueva)
            }
        } finally {
            c.close()
        }
        return res
    }


    //TODO Modifico la creacion de tablas, añadir un campo más (borrado) y en caso de que esta variable esté activada borrado no cargue la base de datos

    fun actualizarBBDD(context: Context?, comunidadAutonoma: ComunidadAutonoma) {
        val db = DBOpenHelper.getInstance(context)!!.writableDatabase
        val values = ContentValues()
        values.put(ComunidadAutonomaContract.Companion.Entrada.COLUMNA_ID,comunidadAutonoma.id)
        values.put(ComunidadAutonomaContract.Companion.Entrada.COLUMNA_NOMBRE,comunidadAutonoma.nombre)
        values.put(ComunidadAutonomaContract.Companion.Entrada.COLUMNA_IMAGEN,comunidadAutonoma.imagen)
        db.update(ComunidadAutonomaContract.Companion.Entrada.NOMBRE_TABLA,values,"id=?",arrayOf(comunidadAutonoma.id.toString()))
        db.close()
    }

    fun borrarBBDD(mainActivity: MainActivity, id: Int) {
        val comunidad = listaComunidadesAutonomas.find { it.id == id }
        if (comunidad != null) {
            comunidad?.esVisible = 0
            mainActivity.miDAO.actualizarBBDD(mainActivity, comunidad)
        }
    }
}

