package com.example.unidad05casopractico.activities

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import com.example.unidad05casopractico.R

class EditComunidadAutonomaActivity : AppCompatActivity() {
    private lateinit var binding: EditComunidadAutonomaActivity
    private var id: Int = 0

    @SuppressLint("SuspiciousIndentation")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_comunidad_autonoma)
        val nombre = intent.getStringExtra("nombreComunidadAutonoma")
        val imagen = intent.getIntExtra("imagenComunidadAutonoma", 0)
        id = intent.getIntExtra("idComunidadAutonoma", 0)

        val nombreEdit = findViewById<EditText>(R.id.etNombre)
        var imagenEdit = findViewById<ImageView>(R.id.imgComunidadAutonoma)
        imagenEdit.setImageResource(imagen)
        nombreEdit.hint = nombre


        val btnEditar = findViewById<Button>(R.id.btnEditar)
        btnEditar.isEnabled = false // Deshabilito el botón Editar por el momento

        btnEditar.setOnClickListener{
            val intent = Intent(this, MainActivity::class.java)
            val nombre = nombreEdit.text.toString()

                intent.putExtra("nombreComunidadAutonoma", nombre)
                intent.putExtra("imagenComunidadAutonoma", imagen)
                intent.putExtra("idComunidadAutonoma", id)
                setResult(RESULT_OK, intent)
            Toast.makeText(this, "Ahora el nombre de la Comunidad Autónoma es $nombre", Toast.LENGTH_LONG).show()
            finish()
            }

        // Añado un TextChangedListener al campo de texto para comprobar los cambios en el editText
        nombreEdit.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
                // Se llamajusto antes de que el texto. No es necesario implementar esto
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                // Se activa cuando el texto cambia
                btnEditar.isEnabled = true//Vuelvo a activar el botón

            }

            override fun afterTextChanged(s: Editable?) {
                // Se activa después de que  el texto haya cambiado. Para lo que quiero hacer puedo ponerlo aquí o en el onTextChanged
                //textoEditado = true
                //btnEditar.isEnabled = true
            }
        })

        val btnCancelar = findViewById<Button>(R.id.btnCancelar)
        btnCancelar.setOnClickListener {
            //onBackPressed() Esto no destruye la actividad
            finish()
        }


    }
}
