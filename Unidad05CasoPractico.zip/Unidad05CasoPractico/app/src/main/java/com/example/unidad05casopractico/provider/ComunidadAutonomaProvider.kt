package com.example.unidad05casopractico.provider

import com.example.unidad05casopractico.R
import com.example.unidad05casopractico.model.ComunidadAutonoma

class ComunidadAutonomaProvider {
    companion object{
        var listaComunidadesAutonomas= mutableListOf(
            ComunidadAutonoma(1, "Andalucia", R.drawable.andalucia,1),
            ComunidadAutonoma(2,"Aragon", R.drawable.aragon,1),
            ComunidadAutonoma(3, "Asturias", R.drawable.asturias,1),
            ComunidadAutonoma(4, "Baleares", R.drawable.baleares,1),
            ComunidadAutonoma(5, "Canarias", R.drawable.canarias,1),
            ComunidadAutonoma(6, "Cantabria", R.drawable.cantabria,1),
            ComunidadAutonoma(7, "Cataluña", R.drawable.catalunya,1),
            ComunidadAutonoma(8, "Castilla-La Mancha", R.drawable.castilla_la_mancha,1),
            ComunidadAutonoma(9, "Castilla y León", R.drawable.castilla_y_leon,1),
            ComunidadAutonoma(10, "Comunidad de Madrid", R.drawable.madrid,1),
            ComunidadAutonoma(11, "Comunidad Foral de Navarra", R.drawable.navarra,1),
            ComunidadAutonoma(12, "Comunidad Valenciana", R.drawable.valencia,1),
            ComunidadAutonoma(13, "Extremadura", R.drawable.extremadura,1),
            ComunidadAutonoma(14, "Galicia", R.drawable.galicia,1),
            ComunidadAutonoma(15,  "Murcia", R.drawable.murcia,1),
            ComunidadAutonoma(16, "La Rioja", R.drawable.rioja,1),
            ComunidadAutonoma(17, "País Vasco", R.drawable.pais_vasco,1)
        )

        /*//A continuación guardo la listaComunidadesAutonomas en una variable nuevaLista
        var nuevaLista = listaComunidadesAutonomas.toList().toMutableList()*/
    }
}